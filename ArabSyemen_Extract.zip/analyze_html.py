from html.parser import HTMLParser
from pathlib import Path
from collections import Counter
import re

class Scan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = Counter()
        self.ids = []
        self.classes = []
        self.hidden = []
        self.buttons = []
        self.inputs = []
        self.forms = []
        self.scripts = []
        self.styles = []
        self.events = []
        self.depth = 0

    def handle_starttag(self, tag, attrs):
        self.inspect(tag, attrs)

    def handle_startendtag(self, tag, attrs):
        self.inspect(tag, attrs)

    def inspect(self, tag, attrs):
        self.tags[tag] += 1
        a = dict(attrs)
        if a.get('id'):
            self.ids.append(a['id'])
        if a.get('class'):
            self.classes.extend(a['class'].split())

        style = a.get('style', '').lower().replace(' ', '')
        if ('display:none' in style or 'visibility:hidden' in style
                or 'opacity:0' in style or 'hidden' in a
                or a.get('aria-hidden') == 'true'):
            self.hidden.append(
                f"{tag} id={a.get('id','')} class={a.get('class','')} "
                f"reason=hidden"
            )

        if tag in ('button', 'a'):
            if tag == 'button' or a.get('onclick'):
                self.buttons.append(
                    f"{tag} id={a.get('id','')} class={a.get('class','')}"
                )

        if tag in ('input', 'textarea', 'select'):
            self.inputs.append(
                f"{tag} id={a.get('id','')} name={a.get('name','')} "
                f"type={a.get('type','')}"
            )

        if tag == 'form':
            self.forms.append(
                f"method={a.get('method','')} action={a.get('action','')}"
            )

        if tag == 'script' and a.get('src'):
            self.scripts.append(a['src'])
        if tag == 'link' and 'stylesheet' in a.get('rel','').lower():
            self.styles.append(a.get('href',''))

        for key, value in attrs:
            if key and key.lower().startswith('on'):
                names = re.findall(r'([A-Za-z_$][\w$]*)\s*\(', value or '')
                self.events.append(
                    f"{key}: {', '.join(sorted(set(names))) or 'event handler'}"
                )

files = sorted(Path('.').glob('*.html'))
out = []
out.append("HTML STRUCTURE ANALYSIS - ArabSyemen")
out.append("ملاحظة: لم يتم تسجيل نصوص الصفحات أو الرسائل أو قيم الحقول.")
for file in files:
    parser = Scan()
    try:
        parser.feed(file.read_text(encoding='utf-8', errors='replace'))
    except Exception as e:
        out.append(f"\nتعذر تحليل {file.name}: {e}")
        continue

    out += [
        f"\n{'='*55}",
        f"FILE: {file.name}",
        f"عدد العناصر: {sum(parser.tags.values())}",
        f"العناصر حسب النوع: {dict(parser.tags)}",
        f"\nالمعرفات ID ({len(parser.ids)}):",
        *parser.ids,
        f"\nأصناف CSS ({len(parser.classes)}):",
        *sorted(set(parser.classes)),
        f"\nالعناصر المخفية المكتشفة ({len(parser.hidden)}):",
        *parser.hidden,
        f"\nالأزرار والروابط التفاعلية ({len(parser.buttons)}):",
        *parser.buttons,
        f"\nالحقول ({len(parser.inputs)}):",
        *parser.inputs,
        f"\nالنماذج ({len(parser.forms)}):",
        *parser.forms,
        f"\nأحداث HTML:",
        *sorted(set(parser.events)),
        f"\nملفات JavaScript:",
        *parser.scripts,
        f"\nملفات CSS:",
        *parser.styles
    ]

Path("HTML_STRUCTURE_REPORT.txt").write_text(
    "\n".join(out), encoding="utf-8"
)
print("اكتمل الفحص.")
print("عدد صفحات HTML:", len(files))
print("تم إنشاء HTML_STRUCTURE_REPORT.txt")
print("لم تتم طباعة نصوص المحادثات أو قيم الحقول.")
